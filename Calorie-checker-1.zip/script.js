const form = document.querySelector("form");
const total = document.querySelector("#total");
const mealsList = document.createElement("ul");
document.body.appendChild(mealsList);
const endDayButton = document.createElement("button");
endDayButton.textContent = "End Day";
endDayButton.style.marginTop = "20px";
document.body.appendChild(endDayButton);

let calories = 0;
let meals = [];
let dailyTotal = [];

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const meal = document.querySelector("#meal").value;
  const caloriesPerMeal = parseInt(document.querySelector("#calories").value);
  calories += caloriesPerMeal;
  meals.push({ meal, caloriesPerMeal });
  renderMeals();
  form.reset();
});

endDayButton.addEventListener("click", () => {
  dailyTotal.push(calories);
  if (dailyTotal.length > 3) {
    dailyTotal.shift();
  }
  calories = 0;
  meals = [];
  renderMeals();
  alert(`Total calories for the day: ${dailyTotal[dailyTotal.length - 1]}`);
});

function renderMeals() {
  total.textContent = calories;
  mealsList.innerHTML = "";
  for (const { meal, caloriesPerMeal } of meals) {
    const mealItem = document.createElement("li");
    mealItem.textContent = `Meal: ${meal}, Calories: ${caloriesPerMeal}`;
    mealsList.appendChild(mealItem);
  }
}